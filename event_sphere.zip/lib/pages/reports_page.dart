// lib/pages/reports_page.dart
// <CHANGE> Removed Firestore queries, using mock data

import 'package:flutter/material.dart';

class ReportsPage extends StatelessWidget {
  const ReportsPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Mock data
    const total = 25;
    const attended = 18;
    const attendanceRate = (attended / total) * 100;

    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        backgroundColor: Colors.blue[700],
        title: const Text('Event Reports', style: TextStyle(color: Colors.white)),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Event Statistics', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blue[800])),
            const SizedBox(height: 20),

            // Stats Cards
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              children: [
                _buildStatCard('Total Registrations', '$total', Colors.blue),
                _buildStatCard('Attended', '$attended', Colors.green),
                _buildStatCard('Attendance Rate', '${attendanceRate.toStringAsFixed(1)}%', Colors.orange),
                _buildStatCard('No-Shows', '${total - attended}', Colors.red),
              ],
            ),
            const SizedBox(height: 24),

            Text('Summary', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blue[800])),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Total participants for all events: $total',
                    style: TextStyle(color: Colors.grey[700])),
                  const SizedBox(height: 8),
                  Text('Successfully attended: $attended',
                    style: TextStyle(color: Colors.grey[700])),
                  const SizedBox(height: 8),
                  Text('Attendance rate: ${attendanceRate.toStringAsFixed(1)}%',
                    style: TextStyle(color: Colors.grey[700], fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, String value, MaterialColor color) {
    return Container(
      decoration: BoxDecoration(
        color: color[100],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color[700]!, width: 2),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(value, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: color[700])),
          const SizedBox(height: 8),
          Text(title, style: TextStyle(fontSize: 12, color: color[700]), textAlign: TextAlign.center),
        ],
      ),
    );
  }
}