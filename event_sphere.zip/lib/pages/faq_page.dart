import 'package:flutter/material.dart';
import '../constants/app_theme.dart';

class FaqPageRedesigned extends StatelessWidget {
  FaqPageRedesigned({super.key});
  final List<Map<String, String>> faqs = [
    {
      'q': 'How do I register for an event?',
      'a': 'Navigate to the Events page, browse through available events, select one that interests you, and tap the "Register Now" button on the event details page.',
    },
    {
      'q': 'Can I unregister from an event?',
      'a': 'Yes! You can visit the event details anytime and click the "Unregister from Event" button to remove your registration.',
    },
    {
      'q': 'How do I create an event?',
      'a': 'Click the "Create Event" button on the Events page, fill in all required event details, and submit for approval. Admins will review and approve your event.',
    },
    {
      'q': 'What is the attendance marking system?',
      'a': 'We use QR code scanning for attendance marking. Arrive at the event and let organizers scan your QR code to mark you as present.',
    },
    {
      'q': 'How do I bookmark events?',
      'a': 'You can bookmark events by tapping the bookmark icon on any event card. Your bookmarks are saved in the Bookmarks section for easy access.',
    },
    {
      'q': 'How do societies work?',
      'a': 'Societies are community groups that organize events and activities. You can join societies of interest and stay updated with their events.',
    },
  ];

  // const FaqPageRedesigned({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgPrimary,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'FAQ',
          style: TextStyle(
            color: AppTheme.textPrimary,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: faqs.length,
        itemBuilder: (context, idx) => Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Theme(
            data: Theme.of(context).copyWith(
              dividerColor: Colors.transparent,
            ),
            child: ExpansionTile(
              backgroundColor: Colors.white,
              collapsedBackgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppTheme.cornerRadiusLarge),
                side: const BorderSide(color: AppTheme.borderColor, width: 0.5),
              ),
              collapsedShape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppTheme.cornerRadiusLarge),
                side: const BorderSide(color: AppTheme.borderColor, width: 0.5),
              ),
              title: Text(
                faqs[idx]['q']!,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textPrimary,
                  fontSize: 14,
                ),
              ),
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    faqs[idx]['a']!,
                    style: const TextStyle(
                      color: AppTheme.textSecondary,
                      height: 1.6,
                      fontSize: 13,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
