// lib/pages/registered_events_page.dart
// <CHANGE> Removed Firestore streams, using mock services

import 'package:flutter/material.dart';
import '../services/registration_service.dart';
import '../models/event.dart';
import '../services/event_service.dart';

class RegisteredEventsPage extends StatelessWidget {
  final String userId;
  const RegisteredEventsPage({super.key, required this.userId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        backgroundColor: Colors.blue[700],
        title: const Text('My Registered Events', style: TextStyle(color: Colors.white)),
        elevation: 0,
      ),
      body: StreamBuilder<List<String>>(
        stream: RegistrationService.userEventIdsStream(userId),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          var eventIds = snapshot.data!;
          if (eventIds.isEmpty) {
            return const Center(child: Text("You're not registered for any events."));
          }

          return StreamBuilder<List<Event>>(
            stream: EventService.getEventsStream(),
            builder: (context, eventsSnap) {
              if (!eventsSnap.hasData) return const Center(child: CircularProgressIndicator());
              var events = eventsSnap.data!.where((e) => eventIds.contains(e.id)).toList();

              if (events.isEmpty) return const Center(child: Text('No registered events'));

              return ListView.builder(
                itemCount: events.length,
                itemBuilder: (context, idx) => Card(
                  color: Colors.white,
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: ListTile(
                    title: Text(events[idx].title,
                      style: TextStyle(color: Colors.blue[800], fontWeight: FontWeight.bold)),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 4),
                        Text(events[idx].venue),
                        Text('${events[idx].date.toLocal()}'.split('.').first, style: TextStyle(fontSize: 11, color: Colors.grey[600])),
                      ],
                    ),
                    trailing: const Icon(Icons.check_circle, color: Colors.green),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}