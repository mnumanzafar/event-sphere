// lib/pages/calendar_page.dart
// <CHANGE> Removed Firestore streams, using mock EventService

import 'package:flutter/material.dart';
import '../models/event.dart';
import '../services/event_service.dart';

class CalendarPage extends StatelessWidget {
  const CalendarPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        backgroundColor: Colors.blue[700],
        title: const Text('Event Calendar', style: TextStyle(color: Colors.white)),
        elevation: 0,
      ),
      body: StreamBuilder<List<Event>>(
        stream: EventService.getApprovedEventsStream(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          var events = snapshot.data!;
          var sortedEvents = events..sort((a, b) => a.date.compareTo(b.date));

          if (sortedEvents.isEmpty) {
            return const Center(child: Text('No events scheduled'));
          }

          return ListView.builder(
            itemCount: sortedEvents.length,
            itemBuilder: (context, idx) {
              var event = sortedEvents[idx];
              var dateStr = '${event.date.toLocal()}'.split(' ').first;

              return Card(
                color: Colors.white,
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          color: Colors.blue[700],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Center(
                          child: Text(
                            '${event.date.day}',
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(event.title,
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                            const SizedBox(height: 4),
                            Text(event.venue, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                            Text(dateStr, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}