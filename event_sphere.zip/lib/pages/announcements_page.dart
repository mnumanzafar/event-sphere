// lib/pages/announcements_page.dart
// <CHANGE> Removed Firestore streams, using mock data

import 'package:flutter/material.dart';

class AnnouncementsPage extends StatelessWidget {
  AnnouncementsPage({super.key});

  final List<Map<String, String>> _announcements = [
    {
      'title': 'New Event System Live',
      'date': DateTime.now().toString().split(' ').first,
      'content': 'Check out our new event management system with improved features!',
    },
    {
      'title': 'Society Registration Open',
      'date': DateTime.now().subtract(const Duration(days: 1)).toString().split(' ').first,
      'content': 'New societies can now register through the app',
    },
    {
      'title': 'Maintenance Update',
      'date': DateTime.now().subtract(const Duration(days: 2)).toString().split(' ').first,
      'content': 'System maintenance scheduled for next week',
    },
  ];

  // const AnnouncementsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        backgroundColor: Colors.blue[700],
        title: const Text('Announcements', style: TextStyle(color: Colors.white)),
        elevation: 0,
      ),
      body: _announcements.isEmpty
        ? const Center(child: Text('No announcements'))
        : ListView.builder(
            itemCount: _announcements.length,
            itemBuilder: (context, idx) => Card(
              color: Colors.white,
              margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_announcements[idx]['title']!,
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blue[800])),
                    const SizedBox(height: 4),
                    Text(_announcements[idx]['date']!,
                      style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                    const SizedBox(height: 8),
                    Text(_announcements[idx]['content']!,
                      style: TextStyle(fontSize: 13, color: Colors.grey[700])),
                  ],
                ),
              ),
            ),
          ),
    );
  }
}