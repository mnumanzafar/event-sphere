// lib/pages/qr_generate_page.dart

import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

class QrGeneratePage extends StatelessWidget {
  final String eventId;

  const QrGeneratePage({super.key, required this.eventId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        backgroundColor: Colors.blue[700],
        title: const Text('Event QR Code', style: TextStyle(color: Colors.white)),
      ),
      body: Center(
        child: QrImageView(
          data: eventId,
          version: QrVersions.auto,
          size: 200.0,
          backgroundColor: Colors.white,
        ),
      ),
    );
  }
}
