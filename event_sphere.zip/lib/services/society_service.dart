// lib/services/society_service.dart
// MOCK SERVICE - No Firebase/Supabase

import '../models/society.dart';
import 'dart:async';

class SocietyService {
  static final List<Society> _societies = [
    Society(
      id: 'soc1',
      name: 'Tech Society',
      description: 'For all tech enthusiasts',
      presidentId: 'user2',
    ),
    Society(
      id: 'soc2',
      name: 'Gaming Club',
      description: 'Gamers unite here',
      presidentId: 'user2',
    ),
    Society(
      id: 'soc3',
      name: 'Sports Committee',
      description: 'Sports and fitness',
      presidentId: 'user2',
    ),
  ];

  // Stream: Get societies (initial + updated every 2s)
  static Stream<List<Society>> getSocietiesStream() async* {
    // Emit initial data immediately
    yield List<Society>.from(_societies);

    // Emit updates every 2 seconds
    await for (final _ in Stream.periodic(const Duration(seconds: 2))) {
      yield List<Society>.from(_societies);
    }
  }

  // Create society
  static Future<void> createSociety(Society society) async {
    await Future.delayed(const Duration(milliseconds: 500));
    _societies.add(society);
  }

  // Get single society
  static Future<Society?> getSociety(String societyId) async {
    await Future.delayed(const Duration(milliseconds: 300));
    try {
      return _societies.firstWhere((s) => s.id == societyId);
    } catch (_) {
      return null;
    }
  }
}
