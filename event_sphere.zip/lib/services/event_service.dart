// lib/services/event_service.dart
// MOCK SERVICE - No Firebase/Supabase

import '../models/event.dart';
import 'dart:async';

class EventService {
  static final List<Event> _events = [
    Event(
      id: 'event1',
      title: 'Tech Workshop 2025',
      description: 'Learn Flutter and Dart best practices',
      date: DateTime.now().add(const Duration(days: 7)),
      venue: 'Engineering Block A',
      societyId: 'soc1',
      createdBy: 'user2',
      approvalStatus: 'approved',
    ),
    Event(
      id: 'event2',
      title: 'Networking Event',
      description: 'Meet industry professionals',
      date: DateTime.now().add(const Duration(days: 14)),
      venue: 'Main Hall',
      societyId: 'soc1',
      createdBy: 'user2',
      approvalStatus: 'approved',
    ),
    Event(
      id: 'event3',
      title: 'Gaming Tournament',
      description: 'Compete in esports games',
      date: DateTime.now().add(const Duration(days: 21)),
      venue: 'Gaming Lab',
      societyId: 'soc1',
      createdBy: 'user2',
      approvalStatus: 'pending',
    ),
  ];

  // Stream events (emits every 2 seconds for mock demo)
  static Stream<List<Event>> getEventsStream() async* {
  // Emit initial events immediately
  yield List.from(_events);

  // Then keep emitting every 2 seconds
  await for (final _ in Stream.periodic(const Duration(seconds: 2))) {
    yield List.from(_events);
  }
}


  // Get approved events only
  static Stream<List<Event>> getApprovedEventsStream() {
    return getEventsStream().map(
      (events) => events.where((e) => e.approvalStatus == 'approved').toList(),
    );
  }

  // Get pending events (admin)
  static Stream<List<Event>> getPendingEventsStream() {
    return getEventsStream().map(
      (events) => events.where((e) => e.approvalStatus == 'pending').toList(),
    );
  }

  // Create new event
  static Future<void> createEvent(Event event) async {
    await Future.delayed(const Duration(milliseconds: 500));
    _events.add(event);
  }

  // Update event
  static Future<void> updateEvent(String eventId, Map<String, dynamic> data) async {
    await Future.delayed(const Duration(milliseconds: 500));
    final index = _events.indexWhere((e) => e.id == eventId);

    if (index != -1) {
      final event = _events[index];
      _events[index] = Event(
        id: event.id,
        title: data['title'] ?? event.title,
        description: data['description'] ?? event.description,
        date: data['date'] ?? event.date,
        venue: data['venue'] ?? event.venue,
        societyId: event.societyId,
        createdBy: event.createdBy,
        approvalStatus: data['approvalStatus'] ?? event.approvalStatus,
      );
    }
  }

  // Approve event
  static Future<void> approveEvent(String eventId) async {
    await updateEvent(eventId, {'approvalStatus': 'approved'});
  }

  // Reject event
  static Future<void> rejectEvent(String eventId) async {
    await updateEvent(eventId, {'approvalStatus': 'rejected'});
  }

  // Get single event by id
  static Future<Event?> getEvent(String eventId) async {
    await Future.delayed(const Duration(milliseconds: 300));
    try {
      return _events.firstWhere((e) => e.id == eventId);
    } catch (_) {
      return null;
    }
  }
}

// -------- Stream Extension Fix ----------
extension StartWithExtension<T> on Stream<T> {
  Stream<T> startWith(T value) async* {
    yield value;     // first event emitted immediately
    yield* this;     // then continue with original stream
  }
}
