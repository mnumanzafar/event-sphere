// lib/services/bookmark_service.dart
// MOCK SERVICE - No Firebase/Supabase

import 'dart:async';

class BookmarkService {
  static final Map<String, List<String>> _bookmarks = {
    'user1': ['event1'],
  };

  // Get bookmarked event IDs
  static Stream<List<String>> getBookmarksStream(String userId) {
    return Stream.periodic(
      const Duration(seconds: 2),
      (_) => _bookmarks[userId] ?? [],
    ).startWith(_bookmarks[userId] ?? []);
  }

  // Add bookmark
  static Future<void> addBookmark(String userId, String eventId) async {
    await Future.delayed(const Duration(milliseconds: 300));
    if (!_bookmarks.containsKey(userId)) {
      _bookmarks[userId] = [];
    }
    if (!_bookmarks[userId]!.contains(eventId)) {
      _bookmarks[userId]!.add(eventId);
    }
  }

  // Remove bookmark
  static Future<void> removeBookmark(String userId, String eventId) async {
    await Future.delayed(const Duration(milliseconds: 300));
    _bookmarks[userId]?.remove(eventId);
  }

  // Check if bookmarked
  static bool isBookmarked(String userId, String eventId) {
    return _bookmarks[userId]?.contains(eventId) ?? false;
  }
}

// -------- Stream Extension Fix ----------
extension StartWithExtension<T> on Stream<T> {
  Stream<T> startWith(T value) async* {
    yield value; // emit the initial value immediately
    yield* this; // then emit the rest of the stream
  }
}
