// lib/services/registration_service.dart
// MOCK SERVICE - No Firebase/Supabase

import 'dart:async';

class RegistrationService {
  static final Map<String, List<String>> _registrations = {
    'user1': ['event1', 'event2'],
    'user2': ['event1'],
  };

  // Stream: Get event IDs for a user (initial + periodic updates)
  static Stream<List<String>> userEventIdsStream(String userId) async* {
    // Emit initial list immediately
    yield List<String>.from(_registrations[userId] ?? []);

    // Emit updated list every 2 seconds
    await for (final _ in Stream.periodic(const Duration(seconds: 2))) {
      yield List<String>.from(_registrations[userId] ?? []);
    }
  }

  // Register user for event
  static Future<void> registerForEvent(String userId, String eventId) async {
    await Future.delayed(const Duration(milliseconds: 500));

    if (!_registrations.containsKey(userId)) {
      _registrations[userId] = [];
    }

    if (!_registrations[userId]!.contains(eventId)) {
      _registrations[userId]!.add(eventId);
    }
  }

  // Unregister user from event
  static Future<void> unregisterFromEvent(String userId, String eventId) async {
    await Future.delayed(const Duration(milliseconds: 500));
    _registrations[userId]?.remove(eventId);
  }

  // Check if user is registered
  static bool isRegistered(String userId, String eventId) {
    return _registrations[userId]?.contains(eventId) ?? false;
  }

  // Mark attendance (placeholder)
  static Future<void> markAttendance(String userId, String eventId) async {
    await Future.delayed(const Duration(milliseconds: 300));
    // In real app: update attendance status in DB
  }
}
