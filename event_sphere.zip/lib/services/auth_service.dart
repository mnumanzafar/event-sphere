// lib/services/auth_service.dart
// MOCK SERVICE - No Firebase/Supabase

import '../models/user.dart';

class AuthService {
  static final List<User> _users = [
    User(
      id: 'user1',
      email: 'student@example.com',
      name: 'Ahmed Ali',
      role: UserRole.student,
      societyIds: ['soc1'],
    ),
    User(
      id: 'user2',
      email: 'president@example.com',
      name: 'Fatima Khan',
      role: UserRole.president,
      societyIds: ['soc1'],
    ),
    User(
      id: 'user3',
      email: 'admin@example.com',
      name: 'Admin User',
      role: UserRole.admin,
      societyIds: [],
    ),
  ];

  static User? _currentUser;

  // ------------------------- LOGIN -------------------------
  static Future<void> signIn(String email, String password) async {
    await Future.delayed(const Duration(milliseconds: 500)); // Simulate delay
    final user = _users.firstWhere(
      (u) => u.email == email,
      orElse: () => throw Exception('Invalid email or password'),
    );
    _currentUser = user;
  }

  // ------------------------- REGISTER -------------------------
  static Future<void> register(
    String email,
    String password,
    UserRole role,
    String name,
  ) async {
    await Future.delayed(const Duration(milliseconds: 500));

    if (_users.any((u) => u.email == email)) {
      throw Exception('Email already registered');
    }

    final newUser = User(
      id: 'user_${DateTime.now().millisecondsSinceEpoch}',
      email: email,
      name: name,
      role: role,
      societyIds: [],
    );

    _users.add(newUser);
    _currentUser = newUser;
  }

  // ------------------------- GET CURRENT USER -------------------------
  static User? getCurrentUser() {
    return _currentUser;
  }

  // ------------------------- USER PROFILE -------------------------
  static Future<Map<String, dynamic>> getUserProfile(String userId) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final user = _users.firstWhere((u) => u.id == userId);
    return {
      'id': user.id,
      'email': user.email,
      'name': user.name,
      'role': user.role.toString(),
      'societyIds': user.societyIds,
    };
  }

  // ------------------------- UPDATE PROFILE -------------------------
  static Future<void> updateProfile(String userId, Map<String, dynamic> data) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final userIndex = _users.indexWhere((u) => u.id == userId);
    if (userIndex != -1) {
      final user = _users[userIndex];
      _users[userIndex] = User(
        id: user.id,
        email: data['email'] ?? user.email,
        name: data['name'] ?? user.name,
        role: user.role,
        societyIds: user.societyIds,
      );
    }
  }

  // ------------------------- LOGOUT -------------------------
  static Future<void> signOut() async {
    await Future.delayed(const Duration(milliseconds: 300));
    _currentUser = null;
  }

  // ------------------------- AUTH CHECK -------------------------
  static bool isAuthenticated() {
    return _currentUser != null;
  }

  // ------------------------- REQUIRED BY SPLASH SCREEN -------------------------
  static bool get isLoggedIn => _currentUser != null;
}
