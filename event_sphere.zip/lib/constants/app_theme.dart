import 'package:flutter/material.dart';

class AppTheme {
  static const Color primaryColor = Color(0xFF2563EB); // Vivid Blue
  static const Color primaryDark = Color(0xFF1E40AF); // Dark Blue
  static const Color primaryLight = Color(0xFFDBEAFE); // Light Blue

  static const Color accentColor = Color(0xFF7C3AED); // Purple accent
  static const Color successColor = Color(0xFF10B981); // Green
  static const Color warningColor = Color(0xFFF59E0B); // Amber
  static const Color dangerColor = Color(0xFFEF4444); // Red

  static const Color bgPrimary = Color(0xFFFAFBFC); // Off-white
  static const Color bgSecondary = Color(0xFFF3F4F6); // Light gray
  static const Color textPrimary = Color(0xFF111827); // Almost black
  static const Color textSecondary = Color(0xFF6B7280); // Medium gray
  static const Color borderColor = Color(0xFFE5E7EB); // Light border

  static final ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    colorScheme: const ColorScheme.light(
      primary: primaryColor,
      secondary: accentColor,
      surface: bgPrimary,
      error: dangerColor,
      brightness: Brightness.light,
    ),
  );

  static const double cornerRadiusSmall = 8.0;
  static const double cornerRadiusMedium = 12.0;
  static const double cornerRadiusLarge = 16.0;
}
