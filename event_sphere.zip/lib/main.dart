import 'package:flutter/material.dart';
import 'pages/splash_screen.dart';
import 'pages/login_page.dart';
import 'pages/registration_page.dart';
import 'pages/home_page.dart';
import 'pages/events_page.dart';
import 'pages/add_event_page.dart';
import 'pages/event_detail_page.dart';
import 'pages/registered_events_page.dart';
import 'pages/calendar_page.dart';
import 'pages/societies_page.dart';
import 'pages/profile_page.dart';
import 'pages/expenses_page.dart';
import 'pages/bookmarks_page.dart';
import 'pages/announcements_page.dart';
import 'pages/event_approval_page.dart';
import 'pages/admin_dashboard_page.dart';
import 'pages/reports_page.dart';
import 'pages/faq_page.dart';
import 'pages/poll_page.dart';
import 'pages/qr_generate_page.dart';
import 'pages/qr_scan_page.dart';
import 'pages/public_events_page.dart';
import 'pages/chatbot_page.dart';
import 'services/auth_service.dart';

void main() {
  runApp(const EventManagementApp());
}

class EventManagementApp extends StatelessWidget {
  const EventManagementApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Event Sphere',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        primaryColor: const Color(0xFF1976D2),
        scaffoldBackgroundColor: Colors.blue[50],
        useMaterial3: true,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.blue[700],
          foregroundColor: Colors.white,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue[700],
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
      home:  SplashScreen(),
      routes: {
        '/login': (context) =>  LoginPage(),
        '/register': (context) =>  RegistrationPage(),
        '/home': (context) =>  HomePage(),
        '/events': (context) =>  EventsPage(),
        '/add-event': (context) =>  AddEventPage(),
        '/calendar': (context) =>  CalendarPage(),
        '/societies': (context) =>  SocietiesPage(),
        '/profile': (context) =>  ProfilePage(),
        '/expenses': (context) =>  ExpensesPageRedesigned(),
        '/bookmarks': (context) =>  BookmarksPage(),
        '/announcements': (context) =>  AnnouncementsPage(),
        '/event-approval': (context) =>  EventApprovalPage(),
        '/admin-dashboard': (context) =>  AdminDashboardPage(),
        '/reports': (context) =>  ReportsPage(),
        '/faq': (context) =>  FaqPageRedesigned(),
        '/poll': (context) =>  PollPageRedesigned(),
        '/qr-scan': (context) =>  QrScanPage(),
        '/chatbot': (context) =>  ChatbotPage(),
      },
      onGenerateRoute: (settings) {
        // Event Detail Page
        if (settings.name == '/event-detail') {
          final eventId = settings.arguments as String;
          return MaterialPageRoute(
            builder: (context) => EventDetailPage(eventId: eventId),
          );
        }

        // QR Generate Page
        if (settings.name == '/qr-generate') {
          final eventId = settings.arguments as String;
          return MaterialPageRoute(
            builder: (context) => QrGeneratePage(eventId: eventId),
          );
        }

        // Public Events Page
        if (settings.name == '/public-events') {
          final userRole = settings.arguments as String;
          return MaterialPageRoute(
            builder: (context) => PublicEventsPage(userRole: userRole),
          );
        }

        // Registered Events Page (needs current user)
        if (settings.name == '/registered-events') {
          final user = AuthService.getCurrentUser();
          return MaterialPageRoute(
            builder: (context) =>
                user != null ? RegisteredEventsPage(userId: user.id) :  LoginPage(),
          );
        }

        return null; // unknown route
      },
    );
  }
}
