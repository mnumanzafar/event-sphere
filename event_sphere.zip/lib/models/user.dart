// lib/models/user.dart
// User model - No changes needed, already clean

enum UserRole { student, president, admin }

class User {
  final String id;
  final String email;
  final String name;
  final UserRole role;
  final List<String> societyIds;

  User({
    required this.id,
    required this.email,
    required this.name,
    required this.role,
    required this.societyIds,
  });
}