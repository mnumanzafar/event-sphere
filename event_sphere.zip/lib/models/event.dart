// lib/models/event.dart
// Event model - No changes needed, already clean

class Event {
  final String id;
  final String title;
  final String description;
  final DateTime date;
  final String venue;
  final String societyId;
  final String createdBy;
  final String approvalStatus; // 'pending', 'approved', 'rejected'

  Event({
    required this.id,
    required this.title,
    required this.description,
    required this.date,
    required this.venue,
    required this.societyId,
    required this.createdBy,
    required this.approvalStatus,
  });
}